<?php
$homepage = file_get_contents('https://questreality.ru/api/timetable_liveq/25.json');
echo $homepage;
?>
