<?php
$homepage = file_get_contents('https://questreality.ru/api/timetable_liveq/34.json');
echo $homepage;
?>
