<?php
$homepage = file_get_contents('https://questreality.ru/api/timetable_liveq/23.json');
echo $homepage;
?>
