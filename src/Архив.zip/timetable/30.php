<?php
$homepage = file_get_contents('https://questreality.ru/api/timetable_liveq/30.json');
echo $homepage;
?>
