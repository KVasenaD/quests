<?php
$homepage = file_get_contents('https://questreality.ru/api/timetable_liveq/16.json');
echo $homepage;
?>
